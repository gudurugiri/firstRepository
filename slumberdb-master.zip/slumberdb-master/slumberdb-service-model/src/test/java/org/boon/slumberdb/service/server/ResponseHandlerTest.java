package org.boon.slumberdb.service.server;

import junit.framework.TestCase;
import org.junit.Test;

/**
 * Created by Richard on 9/15/14.
 */
public class ResponseHandlerTest extends TestCase {


    @Test
    public void test() {

        ResponseHandler responseHandler = new ResponseHandler();


    }
}
