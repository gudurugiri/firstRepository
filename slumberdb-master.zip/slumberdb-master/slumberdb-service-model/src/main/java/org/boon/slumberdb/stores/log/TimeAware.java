package org.boon.slumberdb.stores.log;


public interface TimeAware {

    public void tick(long time);
}
