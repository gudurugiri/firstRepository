package org.boon.slumberdb.service.results;

import org.boon.slumberdb.stores.DataStoreSource;

/**
 * Created by Richard on 9/4/14.
 */
public class Response {
    protected DataStoreSource source;

    public DataStoreSource source() {
        return source;
    }

}
