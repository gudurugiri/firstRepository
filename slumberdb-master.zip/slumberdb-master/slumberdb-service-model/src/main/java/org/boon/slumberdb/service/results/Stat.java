package org.boon.slumberdb.service.results;

/**
 * Created by Richard on 9/4/14.
 */
public class Stat extends Response {

    public String toTextMessage() {
        return "Stat";
    }
}
