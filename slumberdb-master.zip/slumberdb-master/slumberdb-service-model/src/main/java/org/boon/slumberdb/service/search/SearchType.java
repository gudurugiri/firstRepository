package org.boon.slumberdb.service.search;

/**
 * @author JD
 */
public enum SearchType {
    KEY,
    VALUE;
}
