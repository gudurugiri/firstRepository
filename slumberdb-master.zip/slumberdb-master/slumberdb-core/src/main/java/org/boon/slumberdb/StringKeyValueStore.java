package org.boon.slumberdb;


/**
 * This represents a simple interface that stores UTF-8 Strings.
 */
public interface StringKeyValueStore extends KeyValueStore<String, String> {
}