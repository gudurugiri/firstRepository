package org.boon.slumberdb.config;

/**
 * Created by Richard on 5/19/14.
 */
public class GlobalConfig {


    public static final boolean DEBUG = Boolean.getBoolean("slumberdb.DEBUG");

    public static final boolean VERBOSE = Boolean.getBoolean("slumberdb.VERBOSE");
}
