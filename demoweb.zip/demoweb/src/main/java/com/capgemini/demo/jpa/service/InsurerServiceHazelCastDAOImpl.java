package com.capgemini.demo.jpa.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Repository;

import com.capgemini.demo.exceptions.InsuredMasterModelNotFound;
import com.capgemini.demo.jpa.InsuredMasterEntity;
import com.capgemini.demo.jpa.InsurerRepository;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.MapLoaderLifecycleSupport;
import com.hazelcast.core.MapStore;

@Repository
public class InsurerServiceHazelCastDAOImpl implements MapStore<Long, InsuredMasterEntity>, MapLoaderLifecycleSupport, ApplicationContextAware{

	@Resource
	private InsurerRepository insurerRepository;
	
	private static ApplicationContext context;

	
	@Autowired
	InsurerService insurerService;
	
	@Override
	public InsuredMasterEntity load(Long id) {
		InsuredMasterEntity insuredMasterEntity = insurerRepository.findOne(id);;
		return insuredMasterEntity;
	}

	@Override
	public Map<Long, InsuredMasterEntity> loadAll(Collection<Long> arg0) {
		 Map<Long, InsuredMasterEntity> insuredMasterMap = 
                 new HashMap<Long, InsuredMasterEntity>();
     List<InsuredMasterEntity> insuredMasterEntityList = insurerRepository.findAll();
     for (InsuredMasterEntity obj : insuredMasterEntityList) {
    	 insuredMasterMap.put(obj.getInsuredID(), obj);
     }
     return insuredMasterMap;
	}

	@Override
	public Iterable<Long> loadAllKeys() {
		 Map<Long, InsuredMasterEntity> insuredMasterMap = 
                 new HashMap<Long, InsuredMasterEntity>();
     List<InsuredMasterEntity> insuredMasterEntityList = insurerRepository.findAll();
     for (InsuredMasterEntity obj : insuredMasterEntityList) {
    	 insuredMasterMap.put(obj.getInsuredID(), obj);
     }
     return insuredMasterMap.keySet();
		
	}

	@Override
	public void delete(Long id) {
		InsuredMasterEntity deletedInsuredMasterEntity = insurerRepository.findOne(id);

		if (deletedInsuredMasterEntity == null)
			try {
				throw new InsuredMasterModelNotFound();
			} catch (InsuredMasterModelNotFound e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		insurerRepository.delete(deletedInsuredMasterEntity);

	}

	@Override
	public void deleteAll(Collection<Long> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void store(Long id, InsuredMasterEntity insuredMasterEntity) {
		
		insurerRepository.save(insuredMasterEntity);
		
	}

	@Override
	public void storeAll(Map<Long, InsuredMasterEntity> insuredMasterMap) {

		for (Map.Entry<Long, InsuredMasterEntity> mapEntry : insuredMasterMap.entrySet()) {
            store(mapEntry.getKey(), mapEntry.getValue());
        }
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init(HazelcastInstance arg0, Properties arg1, String arg2) {
		insurerRepository = (InsurerRepository)context.getBean("insurerRepository");
		
	}

	@Override
	public void setApplicationContext(ApplicationContext con)
			throws BeansException {
		context = 	con;
	}

}
