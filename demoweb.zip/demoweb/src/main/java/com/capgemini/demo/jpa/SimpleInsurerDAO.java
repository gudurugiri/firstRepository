package com.capgemini.demo.jpa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.capgemini.demo.model.InsuredMasterModel;

@Component
public class SimpleInsurerDAO {

	@Autowired
	private DataSource dataSource;

	@Autowired
	JdbcTemplate jdbcTemplate;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public void insert(InsuredMasterModel insuredMasterModel) {

		StringBuffer sql = new StringBuffer().append("INSERT INTO insuredmaster (insuredid, "+ " insfirstname,"
				+ "    inslastname," + " insphonenumber," + "    insphonetype," + "    insemailaddress,"
				+ "    insmailaddrline1," + "    insmailaddrline2," + "    insmailaddrline3," + "    insmailaddrcity,"
				+ "    insmailaddrstate," + "    insmailaddrzip," + "    insmailaddrzipxtn," + " insmailaddrcountry"
				+ ") VALUES ( INSUREDID_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

		Connection conn = null;

		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql.toString());
			//ps.setLong(1, insuredMasterModel.getInsuredID());
			ps.setString(1, insuredMasterModel.getInsFirstName());
			ps.setString(2, insuredMasterModel.getInsLastName());
			ps.setString(3, insuredMasterModel.getInsPhoneNumber());
			ps.setString(4, insuredMasterModel.getInsPhoneType());
			ps.setString(5, insuredMasterModel.getInsEmailAddress());
			ps.setString(6, insuredMasterModel.getInsMailAddrLine1());
			ps.setString(7, insuredMasterModel.getInsMailAddrLine2());
			ps.setString(8, insuredMasterModel.getInsMailAddrLine3());
			ps.setString(9, insuredMasterModel.getInsMailAddrCity());
			ps.setString(10, insuredMasterModel.getInsMailAddrState());
			ps.setString(11, insuredMasterModel.getInsMailAddrZip());
			ps.setString(12, insuredMasterModel.getInsMailAddrZipXtn());
			ps.setString(13, insuredMasterModel.getInsMailAddrCountry());

			ps.executeUpdate();
			ps.close();

		} catch (SQLException e) {
			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
	}

	public InsuredMasterModel findByInsurerId(Long id) {
		InsuredMasterModel insuredMasterModel = null;
		StringBuffer sql = new StringBuffer()
				.append("SELECT insuredid, " + " insfirstname, " + " inslastname, " + " insphonenumber, "
						+ " insphonetype, " + " insemailaddress, " + " insmailaddrline1, " + " insmailaddrline2, "
						+ " insmailaddrline3, " + " insmailaddrcity, " + " insmailaddrstate, " + " insmailaddrzip, "
						+ " insmailaddrzipxtn, " + " insmailaddrcountry from insuredmaster where insuredid = ?");

		Connection conn = null;

		try {
			insuredMasterModel = (InsuredMasterModel) this.jdbcTemplate
					.queryForObject(sql.toString(), new Object[] { id }, new InsurerModelRowMapper());
			return insuredMasterModel;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return insuredMasterModel;

	}
}
