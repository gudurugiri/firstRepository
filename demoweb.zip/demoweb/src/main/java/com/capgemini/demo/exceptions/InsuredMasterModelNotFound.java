package com.capgemini.demo.exceptions;

public class InsuredMasterModelNotFound extends Exception {

}
