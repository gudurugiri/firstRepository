package com.capgemini.demo;

import org.springframework.stereotype.Component;

import com.hazelcast.config.ClasspathXmlConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;

@Component
public class HazelCastConfiguration {

	public static HazelcastInstance hazelCastInstance;
	
	public static HazelcastInstance getHazelCastInstance() {
		if (null == hazelCastInstance)
			hazelCastInstance = Hazelcast
					.newHazelcastInstance(new ClasspathXmlConfig(
							"hazelcast-write-behind.xml"));
		return hazelCastInstance;
	}

	public void setHazelCastInstance(HazelcastInstance hazelCastInstance) {
		// Nothing here
	}
	
}
