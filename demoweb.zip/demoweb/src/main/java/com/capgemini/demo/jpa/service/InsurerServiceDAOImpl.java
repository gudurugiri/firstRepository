package com.capgemini.demo.jpa.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.demo.exceptions.InsuredMasterModelNotFound;
import com.capgemini.demo.jpa.InsuredMasterEntity;
import com.capgemini.demo.jpa.InsurerRepository;

@Service
public class InsurerServiceDAOImpl implements InsurerService {

	@Resource
	private InsurerRepository insurerRepository;

	@Override
	@Transactional
	public void create(InsuredMasterEntity InsuredMasterEntity) {
		InsuredMasterEntity createdInsuredMasterEntity = InsuredMasterEntity;
		insurerRepository.save(createdInsuredMasterEntity);
	}

	@Override
	@Transactional
	public InsuredMasterEntity findById(Long id) {
		return insurerRepository.findOne(id);
	}

	@Override
	@Transactional(rollbackFor = InsuredMasterModelNotFound.class)
	public void delete(Long id) throws InsuredMasterModelNotFound {
		InsuredMasterEntity deletedInsuredMasterEntity = insurerRepository.findOne(id);

		if (deletedInsuredMasterEntity == null)
			throw new InsuredMasterModelNotFound();

		insurerRepository.delete(deletedInsuredMasterEntity);
	}

	@Override
	@Transactional
	public List<InsuredMasterEntity> findAll() {
		return insurerRepository.findAll();
	}

	@Override
	@Transactional(rollbackFor = InsuredMasterModelNotFound.class)
	public InsuredMasterEntity update(InsuredMasterEntity InsuredMasterEntity) throws InsuredMasterModelNotFound {
		InsuredMasterEntity updatedInsuredMasterEntity = insurerRepository.findOne(InsuredMasterEntity.getInsuredID());

		if (updatedInsuredMasterEntity == null)
			throw new InsuredMasterModelNotFound();

		updatedInsuredMasterEntity.setInsFirstName(InsuredMasterEntity.getInsFirstName());
		updatedInsuredMasterEntity.setInsLastName(InsuredMasterEntity.getInsLastName());
		return updatedInsuredMasterEntity;
	}
}
