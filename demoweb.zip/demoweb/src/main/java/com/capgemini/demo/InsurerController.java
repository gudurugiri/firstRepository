/*
 * Copyright 2012-2014 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.capgemini.demo;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.demo.jpa.InsuredMasterEntity;
import com.capgemini.demo.jpa.SimpleInsurerDAO;
import com.capgemini.demo.jpa.service.HazelcastInsurerService;
import com.capgemini.demo.jpa.service.InsurerService;
import com.capgemini.demo.model.InsuredMasterModel;

@Controller
public class InsurerController {

@Autowired
HazelcastInsurerService hazelCastInsurerService;

@Autowired
InsurerService insurerService;

@Autowired
SimpleInsurerDAO simpleInsurerDAO;
	
	@RequestMapping(value = "/policy/addInsurer", method = RequestMethod.GET) 
	public String  displayInsurerForm(Model model) { 
		
		InsuredMasterModel obj = new InsuredMasterModel();
		obj.setInsFirstName("Capgemini");
		obj.setInsLastName("America");
		obj.setInsMailAddrLine1("6400 Shafer Ct");
		obj.setInsMailAddrLine2("Shafer Court");
		obj.setInsEmailAddress("support@capgemini.com");
		obj.setInsMailAddrState("IL");
		obj.setInsMailAddrCity("Rosemont");
		obj.setInsMailAddrZip("600018");
		obj.setInsMailAddrZipXtn("1234");
		obj.setInsPhoneNumber("847-384-6100");
		obj.setInsPhoneType("LAND");
		obj.setInsMailAddrCountry("USA");
		model.addAttribute("InsuredMasterModel", obj);
	    return "insurer"; 
	}
	
	@RequestMapping(value = "/policy/search", method = RequestMethod.GET) 
	public String  search(Model model) { 
		
		InsuredMasterModel obj = new InsuredMasterModel();
		obj.setInsuredID(101L);
		obj.setInsFirstName("Capgemini");
		obj.setInsLastName("America");
		obj.setInsMailAddrLine1("6400 Shafer Ct");
		obj.setInsMailAddrLine2("Shafer Court");
		obj.setInsEmailAddress("support@capgemini.com");
		obj.setInsMailAddrState("IL");
		obj.setInsMailAddrCity("Rosemont");
		obj.setInsMailAddrZip("600018");
		obj.setInsMailAddrZipXtn("1234");
		obj.setInsPhoneNumber("847-384-6100");
		obj.setInsPhoneType("LAND");
		obj.setInsMailAddrCountry("USA");
		model.addAttribute("InsuredMasterModel", obj);
	    return "displayInsurer"; 
	}
	 @RequestMapping(value = "/policy/findInsurer", method = RequestMethod.POST)
	  public String findInsurer(HttpServletRequest request, HttpServletResponse response,
	  @ModelAttribute("InsuredMasterModel") InsuredMasterModel insuredMasterModel, Model model) {
		 
		 InsuredMasterEntity insuredMasterEntity = new InsuredMasterEntity();
		 insuredMasterEntity.setInsuredID(insuredMasterModel.getInsuredID());
		
		 insuredMasterEntity = hazelCastInsurerService.findById(insuredMasterEntity.getInsuredID());
		 //insuredMasterEntity = insurerService.findById(insuredMasterEntity.getInsuredID());
		 //insuredMasterModel = simpleInsurerDAO.findByInsurerId(insuredMasterEntity.getInsuredID());
		 System.out.println(insuredMasterEntity);
		 System.out.println(insuredMasterEntity.getInsFirstName());
		 insuredMasterModel = new InsuredMasterModel();
		 mapEntityToModel(insuredMasterModel, insuredMasterEntity);
		 //System.out.println(insuredMasterModel.getInsFirstName());
		 model.addAttribute("InsuredMasterModel", insuredMasterModel);
		    return "displayInsurer"; 

	  }	
	@RequestMapping(value = "/policy/listdata", method = RequestMethod.GET) 
	public String  listAccessedData(Model model) { 
		List <InsuredMasterModel> InsuredMasterModelList = new ArrayList();
		//Map insurerMap = hazelCastInsurerService.loadAll();
		
		List <InsuredMasterEntity> InsuredMasterEntitylList = insurerService.findAll();// new ArrayList(insurerMap.values());
		
		System.out.println(InsuredMasterEntitylList.size());
		for(InsuredMasterEntity insuredMasterEntity : InsuredMasterEntitylList) {
			InsuredMasterModel obj = new InsuredMasterModel();
			mapEntityToModel(obj, insuredMasterEntity);
			InsuredMasterModelList.add(obj);
		}
		
		model.addAttribute("InsuredMasterModelList", InsuredMasterModelList);
	    return "listAccessed"; 
	}	
	
	
	 @RequestMapping(value = "/policy/saveInsurer", method = RequestMethod.POST)
	  public ModelAndView saveInsurer(HttpServletRequest request, HttpServletResponse response,
	  @ModelAttribute("InsuredMasterModel") InsuredMasterModel insuredMasterModel) {
	  //userService.register(user);
		 
		 //System.out.println(insuredMasterModel.getInsFirstName());
		 InsuredMasterEntity insuredMasterEntity = new InsuredMasterEntity();
		 mapModelToEntity(insuredMasterModel, insuredMasterEntity);
		 
		 hazelCastInsurerService.create(insuredMasterEntity);
		 //simpleInsurerDAO.insert(insuredMasterModel);
	  return new ModelAndView("displayInsurer", "insuredMasterModel", insuredMasterModel);
	  }

	 

	 
	private void mapModelToEntity(InsuredMasterModel insuredMasterModel, InsuredMasterEntity insuredMasterEntity) {

		insuredMasterEntity.setInsEmailAddress(insuredMasterModel.getInsEmailAddress());
		insuredMasterEntity.setInsFirstName(insuredMasterModel.getInsFirstName());
		insuredMasterEntity.setInsLastName(insuredMasterModel.getInsLastName());
		insuredMasterEntity.setInsMailAddrLine1(insuredMasterModel.getInsMailAddrLine1());
		insuredMasterEntity.setInsMailAddrLine2(insuredMasterModel.getInsMailAddrLine2());
		insuredMasterEntity.setInsMailAddrLine3(insuredMasterModel.getInsMailAddrLine3());
		insuredMasterEntity.setInsMailAddrCity(insuredMasterModel.getInsMailAddrCity());
		insuredMasterEntity.setInsMailAddrState(insuredMasterModel.getInsMailAddrState());
		insuredMasterEntity.setInsMailAddrZip(insuredMasterModel.getInsMailAddrZip());
		insuredMasterEntity.setInsMailAddrZipXtn(insuredMasterModel.getInsMailAddrZipXtn());
		insuredMasterEntity.setInsPhoneNumber(insuredMasterModel.getInsPhoneNumber());
		insuredMasterEntity.setInsPhoneType(insuredMasterModel.getInsPhoneType());
		
		insuredMasterEntity.setInsMailAddrCountry(insuredMasterModel.getInsMailAddrCountry());
		
	}
	
	private void mapEntityToModel(InsuredMasterModel insuredMasterModel, InsuredMasterEntity  insuredMasterEntity ) {

		insuredMasterModel.setInsEmailAddress(insuredMasterEntity.getInsEmailAddress());
		insuredMasterModel.setInsFirstName(insuredMasterEntity.getInsFirstName());
		insuredMasterModel.setInsLastName(insuredMasterEntity.getInsLastName());
		insuredMasterModel.setInsMailAddrLine1(insuredMasterEntity.getInsMailAddrLine1());
		insuredMasterModel.setInsMailAddrLine2(insuredMasterEntity.getInsMailAddrLine2());
		insuredMasterModel.setInsMailAddrLine3(insuredMasterEntity.getInsMailAddrLine3());
		insuredMasterModel.setInsMailAddrCity(insuredMasterEntity.getInsMailAddrCity());
		insuredMasterModel.setInsMailAddrState(insuredMasterEntity.getInsMailAddrState());
		insuredMasterModel.setInsMailAddrZip(insuredMasterEntity.getInsMailAddrZip());
		insuredMasterModel.setInsMailAddrZipXtn(insuredMasterEntity.getInsMailAddrZipXtn());
		insuredMasterModel.setInsPhoneNumber(insuredMasterEntity.getInsPhoneNumber());
		insuredMasterModel.setInsPhoneType(insuredMasterEntity.getInsPhoneType());
		insuredMasterModel.setInsMailAddrCountry(insuredMasterEntity.getInsMailAddrCountry());
		
	}	
}
