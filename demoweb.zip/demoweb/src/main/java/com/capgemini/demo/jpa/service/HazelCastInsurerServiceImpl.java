package com.capgemini.demo.jpa.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.demo.HazelCastConfiguration;
import com.capgemini.demo.exceptions.InsuredMasterModelNotFound;
import com.capgemini.demo.jpa.InsuredMasterEntity;

@Service
public class HazelCastInsurerServiceImpl implements HazelcastInsurerService {


	
	@Autowired
	InsurerService insurerService;

	@Autowired
	HazelCastConfiguration hazelCastConfiguration;
	
	@Resource
	private InsurerServiceHazelCastDAOImpl insurerServiceHazelCastDAOImpl;

	@Override
	@Transactional
	public void create(InsuredMasterEntity InsuredMasterEntity) {
		InsuredMasterEntity createdInsuredMasterEntity = InsuredMasterEntity;
		//insurerServiceHazelCastDAOImpl.store(1L, createdInsuredMasterEntity);
		hazelCastConfiguration.getHazelCastInstance().getMap("InsurerMap").put(1L, createdInsuredMasterEntity);
	}

	@Override
	@Transactional
	public InsuredMasterEntity findById(Long id) {
		InsuredMasterEntity insuredMasterEntity = (InsuredMasterEntity) hazelCastConfiguration.getHazelCastInstance().getMap("InsurerMap").get(id);
		return insuredMasterEntity;
	}

	@Override
	@Transactional(rollbackFor = InsuredMasterModelNotFound.class)
	public void delete(Long id) throws InsuredMasterModelNotFound {
		//insurerServiceHazelCastDAOImpl.delete(id);
	 hazelCastConfiguration.getHazelCastInstance().getMap("InsurerMap").delete(id);
	}

	@Override
	@Transactional
	public Map<Object, Object> loadAll() {
		Set arg0 = null;
		List <InsuredMasterEntity>tempList= insurerService.findAll();
		for(InsuredMasterEntity insuredMasterEntity : tempList) {
		hazelCastConfiguration.getHazelCastInstance().getMap("InsurerMap").put(insuredMasterEntity.getInsuredID(), insuredMasterEntity);
		}
		return hazelCastConfiguration.getHazelCastInstance().getMap("InsurerMap").getAll(arg0);
		
	}

	@Override
	@Transactional(rollbackFor = InsuredMasterModelNotFound.class)
	public void update(InsuredMasterEntity InsuredMasterEntity) throws InsuredMasterModelNotFound {
		//InsuredMasterEntity updatedInsuredMasterEntity = insurerServiceHazelCastDAOImpl.load(InsuredMasterEntity.getInsuredID());
		InsuredMasterEntity insuredMasterEntity = (InsuredMasterEntity) hazelCastConfiguration.getHazelCastInstance().getMap("InsurerMap").put(InsuredMasterEntity.getInsuredID(), InsuredMasterEntity);
		
		//insurerServiceHazelCastDAOImpl.store(InsuredMasterEntity.getInsuredID(), InsuredMasterEntity);
	}

}
