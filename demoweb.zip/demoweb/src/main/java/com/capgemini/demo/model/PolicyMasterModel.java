package com.capgemini.demo.model;

import java.io.Serializable;
import java.sql.Date;

public class PolicyMasterModel implements Serializable {

	private static final long serialVersionUID = 1L;

	/*
	 * PolicyID NUMBER PRIMARY KEY, InsuredID NUMBER REFERENCES
	 * InsuredMaster(InsuredID), PolicyType VARCHAR2(20), PolicyEffDate DATE DEFAULT
	 * (sysdate), PolicyExpDate DATE
	 */


	Long policyID;

	String policyType;

	Long insuredId;

	Date policyEffectiveDate;

	Date policyExprityDate;

	public Long getInsuredId() {
		return insuredId;
	}

	public Date getPolicyEffectiveDate() {
		return policyEffectiveDate;
	}

	public Date getPolicyExprityDate() {
		return policyExprityDate;
	}

	public Long getPolicyNumber() {
		return policyID;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setInsuredId(Long insuredId) {
		this.insuredId = insuredId;
	}

	public void setPolicyEffectiveDate(Date policyEffectiveDate) {
		this.policyEffectiveDate = policyEffectiveDate;
	}

	public void setPolicyExprityDate(Date policyExprityDate) {
		this.policyExprityDate = policyExprityDate;
	}

	public void setPolicyNumber(Long policyNumber) {
		this.policyID = policyNumber;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	
	public static PolicyMasterModel getPolicyMasterModel() {
		PolicyMasterModel policyMasterModel = new PolicyMasterModel();
		policyMasterModel.setPolicyType("LIFE");

		policyMasterModel.setInsuredId(102L);

		policyMasterModel.setPolicyEffectiveDate(new Date(System.currentTimeMillis()));
		policyMasterModel.setPolicyExprityDate(new Date(System.currentTimeMillis()));

		return policyMasterModel;

	}

}
