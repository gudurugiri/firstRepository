package com.capgemini.demo.jpa;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.capgemini.demo.model.InsuredMasterModel;

public class InsurerModelRowMapper implements RowMapper{

	@Override
	public Object mapRow(ResultSet rs, int arg1) throws SQLException {

		InsuredMasterModel insuredMasterModel = new InsuredMasterModel();
		
		/*
		 *  insfirstname, " + 
				" inslastname, " + 
				" insphonenumber, " + 
				" insphonetype, " + 
				" insemailaddress, " + 
				" insmailaddrline1, " + 
				" insmailaddrline2, " + 
				" insmailaddrline3, " + 
				" insmailaddrcity, " + 
				" insmailaddrstate, " + 
				" insmailaddrzip, " + 
				" insmailaddrzipxtn, " + 
				" insmailaddrcountry
		 */
		insuredMasterModel.setInsFirstName(rs.getString("insFirstName"));
		insuredMasterModel.setInsLastName(rs.getString("insLastName"));
		insuredMasterModel.setInsPhoneNumber(rs.getString("insPhoneNumber"));
		insuredMasterModel.setInsPhoneType(rs.getString("insPhoneType"));
		insuredMasterModel.setInsEmailAddress(rs.getString("insEmailAddress"));
		insuredMasterModel.setInsMailAddrLine1(rs.getString("insMailAddrLine1"));
		insuredMasterModel.setInsMailAddrLine2(rs.getString("insMailAddrLine2"));
		insuredMasterModel.setInsMailAddrLine3(rs.getString("insMailAddrLine3"));
		insuredMasterModel.setInsMailAddrCity(rs.getString("insMailAddrCity"));
		insuredMasterModel.setInsMailAddrState(rs.getString("insMailAddrState"));
		insuredMasterModel.setInsMailAddrZip(rs.getString("insMailAddrZip"));
		insuredMasterModel.setInsMailAddrZipXtn(rs.getString("insMailAddrZipXtn"));
		insuredMasterModel.setInsMailAddrCountry(rs.getString("insMailAddrCountry"));
		
	
		
		return insuredMasterModel;
	}

}
