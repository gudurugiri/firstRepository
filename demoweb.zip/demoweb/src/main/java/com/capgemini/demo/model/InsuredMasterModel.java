package com.capgemini.demo.model;

import java.io.Serializable;

public class InsuredMasterModel implements Serializable {

	private static final long serialVersionUID = 1L;

	/*
	 * InsuredID NUMBER PRIMARY KEY, InsFirstName VARCHAR2(30), InsLastName
	 * VARCHAR2(30), InsPhoneNumber VARCHAR2(15), InsPhoneType VARCHAR2(4) DEFAULT
	 * ("LAND"), InsEmailAddress VARCHAR2(50), InsMailAddrLine1 VARCHAR2(30),
	 * InsMailAddrLine2 VARCHAR2(30), InsMailAddrLine3 VARCHAR2(30), InsMailAddrCity
	 * VARCHAR2(30), InsMailAddrState VARCHAR2(30), InsMailAddrZip VARCHAR2(10),
	 * InsMailAddrZipXtn VARCHAR2(10), InsMailAddrCountry VARCHAR2(30)
	 */

	Long insuredID;

	String insFirstName;

	String insLastName;

	String insPhoneNumber;

	String insPhoneType;

	String insEmailAddress;

	String insMailAddrLine1;

	String insMailAddrLine2;

	String insMailAddrLine3;

	String insMailAddrCity;

	String insMailAddrState;

	String insMailAddrZip;

	String insMailAddrZipXtn;

	String insMailAddrCountry;

	public Long getInsuredID() {
		return insuredID;
	}

	public void setInsuredID(Long insuredID) {
		this.insuredID = insuredID;
	}

	public String getInsFirstName() {
		return insFirstName;
	}

	public void setInsFirstName(String insFirstName) {
		this.insFirstName = insFirstName;
	}

	public String getInsLastName() {
		return insLastName;
	}

	public void setInsLastName(String insLastName) {
		this.insLastName = insLastName;
	}

	public String getInsPhoneNumber() {
		return insPhoneNumber;
	}

	public void setInsPhoneNumber(String insPhoneNumber) {
		this.insPhoneNumber = insPhoneNumber;
	}

	public String getInsPhoneType() {
		return insPhoneType;
	}

	public void setInsPhoneType(String insPhoneType) {
		this.insPhoneType = insPhoneType;
	}

	public String getInsEmailAddress() {
		return insEmailAddress;
	}

	public void setInsEmailAddress(String insEmailAddress) {
		this.insEmailAddress = insEmailAddress;
	}

	public String getInsMailAddrLine1() {
		return insMailAddrLine1;
	}

	public void setInsMailAddrLine1(String insMailAddrLine1) {
		this.insMailAddrLine1 = insMailAddrLine1;
	}

	public String getInsMailAddrLine2() {
		return insMailAddrLine2;
	}

	public void setInsMailAddrLine2(String insMailAddrLine2) {
		this.insMailAddrLine2 = insMailAddrLine2;
	}

	public String getInsMailAddrLine3() {
		return insMailAddrLine3;
	}

	public void setInsMailAddrLine3(String insMailAddrLine3) {
		this.insMailAddrLine3 = insMailAddrLine3;
	}

	public String getInsMailAddrCity() {
		return insMailAddrCity;
	}

	public void setInsMailAddrCity(String insMailAddrCity) {
		this.insMailAddrCity = insMailAddrCity;
	}

	public String getInsMailAddrState() {
		return insMailAddrState;
	}

	public void setInsMailAddrState(String insMailAddrState) {
		this.insMailAddrState = insMailAddrState;
	}

	public String getInsMailAddrZip() {
		return insMailAddrZip;
	}

	public void setInsMailAddrZip(String insMailAddrZip) {
		this.insMailAddrZip = insMailAddrZip;
	}

	public String getInsMailAddrZipXtn() {
		return insMailAddrZipXtn;
	}

	public void setInsMailAddrZipXtn(String insMailAddrZipXtn) {
		this.insMailAddrZipXtn = insMailAddrZipXtn;
	}

	public String getInsMailAddrCountry() {
		return insMailAddrCountry;
	}

	public void setInsMailAddrCountry(String insMailAddrCountry) {
		this.insMailAddrCountry = insMailAddrCountry;
	}

	public static InsuredMasterModel getInsuredMasterModel() {
		InsuredMasterModel insuredMasterModel = new InsuredMasterModel();

		insuredMasterModel.setInsEmailAddress("test@test.com");
		insuredMasterModel.setInsFirstName("TEST FIRST NAME");
		insuredMasterModel.setInsLastName("TEST LAST NAME");
		insuredMasterModel.setInsMailAddrLine1("STREET 1");
		insuredMasterModel.setInsMailAddrLine2("STREET 2");
		insuredMasterModel.setInsMailAddrLine3("STREET 3");
		insuredMasterModel.setInsMailAddrCity("CHICAGO");
		insuredMasterModel.setInsMailAddrState("IL");
		insuredMasterModel.setInsMailAddrZip("60006");
		insuredMasterModel.setInsMailAddrZipXtn("1234");
		insuredMasterModel.setInsPhoneNumber("123-456-789");
		insuredMasterModel.setInsPhoneType("LAND");

		insuredMasterModel.setInsMailAddrCountry("USA");

		return insuredMasterModel;

	}

}
