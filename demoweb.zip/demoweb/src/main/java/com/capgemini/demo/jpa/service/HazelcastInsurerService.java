package com.capgemini.demo.jpa.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.capgemini.demo.exceptions.InsuredMasterModelNotFound;
import com.capgemini.demo.jpa.InsuredMasterEntity;

@Service
public interface HazelcastInsurerService {

	public void create(InsuredMasterEntity InsuredMasterEntity);
	public void delete(Long id) throws InsuredMasterModelNotFound;
	public Map<Object, Object> loadAll();
	public void update(InsuredMasterEntity InsuredMasterEntity) throws InsuredMasterModelNotFound;
	public InsuredMasterEntity findById(Long id);
	
}
