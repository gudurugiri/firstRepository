package com.capgemini.demo.jpa;

public class InsurerDAO {

	
	
}
