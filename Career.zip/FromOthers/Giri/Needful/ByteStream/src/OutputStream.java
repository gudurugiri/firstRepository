
import java.io.*; 
class OutputStream { 
public static void main(String args[]) throws IOException { 
ByteArrayOutputStream f = new ByteArrayOutputStream(); 
String s = "This should end up in the array"; 
byte buf[] = s.getBytes(); 
f.write(buf); 
 
byte b[] = f.toByteArray(); 
for (int i=0; i<b.length; i++) { 
System.out.print(b[i]); 
} 
}
}
