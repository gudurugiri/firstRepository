import java.io.*;
public class InputStreamToByteArrayInputStream
{
	public static void main(String args[])
	{
	
	//InputStream inputStream= new FileInputStream("InputStreamToByteArrayInputStream.java");
    byte currentXMLBytes[] = "anusha".getBytes();
  
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(currentXMLBytes);
 int x=  0;
 while(x!=-1)
 {System.out.println(x);
	 x=   byteArrayInputStream.read();
	 
	 
	
	}
 
	}
}