package dozer;

public class A {

	String age;

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}
}
