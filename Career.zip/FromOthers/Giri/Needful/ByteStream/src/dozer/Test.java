package dozer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;


public class Test {
	public  Properties  m() throws IOException {
	Properties p= new Properties();
	p.load(getClass().getClassLoader().getResourceAsStream("xyz.properties"));
	
	return p;
	}
	public static void main(String[] args) throws IOException {
		
		A a = new A();
		
		a.setAge("twenty");
		Test t = new Test();
		
		Properties p = t.m();
		
		List l=new ArrayList();
		l.addAll(new ArrayList(p.values()));
		Mapper m = new DozerBeanMapper(l);
		B b = null;
		
	
		b=	m.map(a, B.class,"abc");
	
	
	System.out.println("value of newage in b is ------- " +b.getNewAge());
		
	}

}
