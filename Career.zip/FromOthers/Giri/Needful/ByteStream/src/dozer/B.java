package dozer;

public class B {

	String newAge;

	public String getNewAge() {
		return newAge;
	}

	public void setNewAge(String newAge) {
		this.newAge = newAge;
	}

	
}
