
import java.io.*;
public class Util
{
  public static void main(String args[])
  {
  try
  {
  InputStream inputStream= new FileInputStream
("Util.java");
  byte currentXMLBytes[] = inputStream.toString().getBytes();
  ByteArrayInputStream byteArrayInputStream = new 
ByteArrayInputStream(currentXMLBytes);
  while(byteArrayInputStream.read()!=-1)
  System.out.println(byteArrayInputStream.read());
  }
  catch (IOException e){}
  }
}